export default function Home(){
    return(
        <div>안녕</div>
    )
}