export default function Error({ error, reset }){
    return (
        <div>
            <h4>404 없는 페이지입니다.</h4>
        </div>
    ) 
}